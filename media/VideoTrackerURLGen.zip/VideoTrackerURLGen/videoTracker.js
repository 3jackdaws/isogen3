var Mobile = false;

/**
 * Created by ian on 12/22/16.
 */

window.addEventListener("load", function () {
    loadReplacements();
    updateCustomSubNum();
    if ("ontouchstart" in window) {
        Mobile = true;
    }
});

var replacements = [ ];


function saveReplacements() {
    setCookie("RVAL", JSON.stringify(replacements), 365);
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function clearSubs() {
    var num = replacements.length;
    if(confirm("Delete " + num + " custom replacements?")) {
        replacements     = [];
        document.cookie  = "RVAL=[]";
        updateCustomSubNum();
    }
}

function updateCustomSubNum() {
    var indicator       = document.getElementById("repl-info");
    var num             = replacements.length;
    indicator.innerHTML = "<label>" + num + " LOADED</label>"
}


function loadReplacements() {
    var cval = document.cookie.split(";");
    var len  = cval.length;
    for (var i = 0; i < len; i++) {
        var kv=cval[i].split("=");
        if(kv[0] == "RVAL") {
            replacements = JSON.parse(kv[1]);
        }
    }
}

function generateUrls(event, form) {
    event.preventDefault();
    var query           = form["query"].value;
    var fb              = form['fb'];
    var google          = form['g'];
    var urlOutput       = document.getElementById("url-div");
    urlOutput.innerHTML = "";

    if(fb.checked) {
        var group       = document.createElement("div");
        group.classList = "list-item-group";
        var fbLinks     = generateLinks(query, getFacebookLink);
        urlOutput.appendChild(group);
        group.innerHTML = "<a class='list-group-item'><h4>Facebook</h4></a>"
        outputLinks(fbLinks, group);
    }

    if(google.checked) {
        var group       = document.createElement("div");
        group.classList = "list-item-group";
        var gLinks      = generateLinks(query, getGoogleLink);
        urlOutput.appendChild(group);
        group.innerHTML = "<a class='list-group-item'><h4>Google</h4></a>"
        outputLinks(gLinks, group);
    }
}

var generatedQueries = [];
var maxDepth         = 10;
var depth            = 0;

function performSubstitutions(query) {

    var len = replacements.length;
    for (var i = 0; i < len; i++) {
        var str  = replacements[i][0];
        var repl = replacements[i][1];
        var sub  = query.replace(new RegExp(str, "gi"), repl);

        if(generatedQueries.indexOf(sub) == -1) {
            generatedQueries.push(sub);
            if(depth < maxDepth) {
                depth += 1;
                performSubstitutions(sub);
                depth -= 1;
            }
        }
    }
}

function clearLinks() {
    var urlOutputDiv       = document.getElementById("url-div");
    urlOutputDiv.innerHTML = '';
    generatedQueries       = [];
}

function _disableLink() {
    this.className += " disabled";
}

function outputLinks(links, outputLocation) {

    var len = links.length;
    for (var i = 0; i < len; i++) {
        var text = links[i]["text"];
        var href = links[i]["href"];
        var link = document.createElement("a");

        //allows for overriding the click event
        //used to be used for doing external protocol request for mobile devices: fb://
        if("onclick" in links[i]) {
            link.onclick = links[i]["onclick"];
        }else{
            link.onclick = _disableLink;
        }
        link.href = href;
        link.target = "_blank";

        link.className = "list-group-item";
        link.innerHTML = text;
        outputLocation.appendChild(link);

    }
}


function generateLinks(query, linkGenerator) {
    var links = [];
    generatedQueries.push(query);
    performSubstitutions(query);
    var len = generatedQueries.length;
    for(var i = 0; i<len; i++) {
        links.push(linkGenerator(generatedQueries[i]));
    }
    return links;
}


function getFacebookLink(query) {
    var urlBase = "https://www.facebook.com/search/videos/?q=";
    return {text:query,href:urlBase + encodeURI(query)};
}


function getGoogleLink(query) {
    var urlBase = "http://google.com#q=";
    return {text:query,href:urlBase + encodeURI(query)};
}



function addSubstitution(event, form) {
    event.preventDefault();
    var replace = form["replace"].value.toLowerCase();
    var withh   = form["with"].value.toLowerCase();
    if (replace.length == 0) {
        alert("The \"Replace\" field cannot be blank.");
    }else if(withh.search(replace) != -1) {
        alert("You cannot have a directly recursing substitution.");
    }
    else
    {
        replacements.push([replace, withh]);
        saveReplacements();
        updateCustomSubNum();
        var btn = form.querySelector("button");
        btn.className   = "btn btn-success";
        btn.innerHTML   = "SUBSTITUTION ADDED";
        setTimeout(function () {
            var b = btn;
            b.innerHTML = "ADD SUBSTITUTION";
            b.className = "btn btn-themed";
        }, 2000);
    }
}



function exportSubs() {
    var ta            = document.createElement("textarea");
    ta.style.position = "fixed";
    ta.style.opacity  = 0;
    ta.innerHTML      = JSON.stringify(replacements);
    
    document.body.appendChild(ta);
    ta.select();
    var success       = document.execCommand("copy");
    if (success) {
        alert("Your substitutions have been copied to your clipboard.  Paste them in a word document to save them.");
    }else{
        alert("Copying subs was not correctly carried out.")
    }
    document.body.removeChild(ta);
}


function importSubs() {
    var subs = prompt("Paste your substitution export string here.");
    if(subs)
        try{
            replacements = JSON.parse(subs);
            updateCustomSubNum();
        }catch (e) {
            alert("There are errors in the substitutions you are trying to import.");
        }
}